É necessario que a pasta `lib` esteja na mesma pasta que o arquivo `MainAcademy.jar` e que dentro da pasta lib contenha o arquivo `mysql-connector-java-8.0.23.jar`.
